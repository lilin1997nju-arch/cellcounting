﻿Cell Vision Production Update 2026.08.24-r1
========================================

Install:
1. Put the entire CellVision-Update-20260824-r1 folder in the Cell Vision installation root.
2. Double-click Update-CellVision.cmd and approve the Windows administrator prompt.
3. The updater locates CellVisionProduction, backs up 15 files, replaces them, restarts the service, and checks /api/ready.
4. Installation is complete when update completed successfully is shown.

Rollback:
1. Keep this update folder and the update-backups folder inside the application directory.
2. Double-click Rollback-CellVision.cmd to restore the latest update backup and restart the service.

Notes:
- The updater does not validate a production baseline or individual file hashes.
- Every replaced file is backed up first; a failed update restores this backup automatically.
- Workspace, data, models, Python runtime, and production configuration are not replaced.
- Deferred cell-multiplicity and debris model changes are not included.
